﻿@echo off
setlocal
cd /d "%~dp0"
set GAMEAGENTLAB_HOST=127.0.0.1
set GAMEAGENTLAB_PORT=8001
echo ================================================
echo       GAMEAGENTLAB V2 - VARAGOD
echo ================================================
echo V2 address: http://localhost:%GAMEAGENTLAB_PORT%
echo Version check: http://localhost:%GAMEAGENTLAB_PORT%/health
echo.
where py >nul 2>nul
if %errorlevel%==0 (set PY=py) else (set PY=python)
%PY% --version
if errorlevel 1 (
  echo Python 3 is not installed or not in PATH.
  pause
  exit /b 1
)
if not exist .venv (
  echo Creating virtual environment...
  %PY% -m venv .venv
  if errorlevel 1 goto error
)
call .venv\Scripts\activate.bat
echo Installing/updating required packages...
python -m pip install --upgrade pip
if errorlevel 1 goto error
python -m pip install -r requirements.txt
if errorlevel 1 goto error
echo.
echo Starting GameAgentLab V2 on port %GAMEAGENTLAB_PORT%...
echo Keep this window open while using GameAgentLab V2.
echo Keep LM Studio running with Local Server on port 1234.
echo.
start "" "http://localhost:%GAMEAGENTLAB_PORT%"
python agent.py
if errorlevel 1 (
  echo.
  echo GameAgentLab V2 stopped with an error. Read the message above.
)
pause
exit /b 0
:error
echo.
echo Setup failed. Check Python installation and internet connection.
pause
exit /b 1
