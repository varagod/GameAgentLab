import os
import re
import json
import subprocess
import threading
import urllib.parse
try:
    import httpx
except ImportError:
    httpx = None
import zipfile
import io
import base64
import shutil
from pathlib import Path
from datetime import datetime
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from openai import OpenAI

# --- تنظیمات ---
LM_STUDIO_URL = "http://127.0.0.1:1234/v1"
MODEL_NAME = "google/gemma-4-e4b"
MAX_VISION_IMAGE_BYTES = 12 * 1024 * 1024
MAX_PROMPT_REQUEST_BYTES = 18 * 1024 * 1024
LM_STUDIO_NATIVE_CHAT_URL = LM_STUDIO_URL.rsplit("/v1", 1)[0] + "/api/v1/chat"
SERVER_HOST = os.environ.get("GAMEAGENTLAB_HOST", "127.0.0.1")
SERVER_PORT = int(os.environ.get("GAMEAGENTLAB_PORT", "8001"))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE_DIR = os.path.join(BASE_DIR, "workspace")

http_client = httpx.Client(trust_env=False, timeout=httpx.Timeout(600.0, connect=60.0)) if httpx else None
client = OpenAI(base_url=LM_STUDIO_URL, api_key="lm-studio", **({"http_client": http_client} if http_client else {}))

# =====================================================================
# 🛑 پرامپت ثابت (سخت‌گیرانه)
# =====================================================================
FIXED_PROMPT = """
تو یک مهندس ارشد نرم‌افزار هستی. ⛔ قوانین حیاتی:

🔴 مسیر فایل‌ها: همه فایل‌ها داخل یک پوشه با فاصله هستند، مثل `USG ISHIMURA LAST RUN/js/core.js`. از همان مسیری که در ساختار درختی می‌بینی استفاده کن.

🔴 استراتژی ویرایش (به ترتیب):
1. `grep_file(path, "کلیدواژه")` → پیدا کردن خط دقیق
2. `read_file(path, start_line, end_line)` → خواندن محتوای دقیق آن بخش
3. `edit_file(path, old_string, new_string)` → جایگزینی با old_string که **دقیقاً** از خروجی read_file کپی شده
4. `read_file` مجدد → تأیید اعمال شدن

🔴 NEVER از write_file برای فایل‌های موجود استفاده نکن. write_file فقط فایل جدید.
🔴 هرگز split_file را صدا نزن؛ این ابزار عمداً غیرفعال است.
🔴 قبل از تغییر، وابستگی‌ها و ترتیب بارگذاری فایل‌ها را بررسی کن.
🔴 تغییرات کوچک و موضعی انجام بده؛ فایل سالم را از نو تولید نکن.
🔴 به هیچ وجه فایل‌های خارج از درخواست را تغییر نده.

🔴 اگر edit_file گفت «رشته پیدا نشد»، دوباره read_file بزن (با بازه خطوط دقیق) و old_string را از خروجی کپی کن. حدس نزن.

🔴 فقط یک تغییر کوچک در هر edit_file. اگر ۴ تغییر لازم است، ۴ بار edit_file جداگانه بزن، بین هر کدام read_file کن.

🔴 هرگز فایل‌ها را split نکن. ابزار split_file غیرفعال است؛ فایل بزرگ را با read_file در بازه‌های کوچک بخوان.

🆕 `write_file` فقط برای فایل‌های کاملاً جدید.

✅ در پایان، کلمه 'پایان' را بنویس.
"""

# =====================================================================
# 🧠 پرامپت مهندس پرامپت
# =====================================================================
PROMPT_ENGINEER_SYSTEM = """
تو یک مهندس پرامپت حرفه‌ای هستی. کاربر درخواستی دارد و تو باید برای یک عامل کدنویس، پرامپت دقیق و فنی بنویسی.

مراحل:
1. درخواست کاربر را بفهم.
2. اگر تصویر مرجع پیوست شده است، آن را دقیق بررسی کن: شکل کلی، نسبت ابعاد، اجزا، رنگ‌ها، متریال، جزئیات شاخص و سبک بصری را استخراج کن. تصویر را در پرامپت نهایی به مشخصات قابل اجرا تبدیل کن؛ صرفاً ننویس «مثل تصویر بساز».
3. با ابزار `read_file` فایل‌های مرتبط را بررسی کن.
4. پرامپت کامل بنویس و روشن کن تصویر پیوست‌شده مرجع بصری است، نه فایلی که خودکار داخل پروژه ذخیره شده باشد.

قوانین پرامپت:
- بسیار دقیق باشد (نگو «بهبود بده»، بگو «این کد را در فایل X بعد از خط Y اضافه کن»).
- کدهای دقیق را درج کن.
- به عامل تأکید کن از `edit_file` استفاده کند، نه `write_file`.
- در پایان بنویس «پایان».

⚠️ فقط و فقط خود پرامپت را بنویس. هیچ مقدمه یا نتیجه‌گیری ننویس.
"""

agent_logs = []
log_lock = threading.Lock()
is_running = False
CURRENT_PROJECT = None
MISSION_LOG_PATH = None


def log_ui(message):
    print(message)
    with log_lock:
        if len(agent_logs) > 800:
            agent_logs.pop(0)
        agent_logs.append(message)
        if MISSION_LOG_PATH:
            try:
                with open(MISSION_LOG_PATH, "a", encoding="utf-8") as log_file:
                    log_file.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " | " + str(message) + "\n")
            except OSError:
                pass


# =====================================================================
# 🛠️ ابزارهای عامل اصلی
# =====================================================================
tools = [    
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "خواندن محتوای یک فایل. برای فایل‌های بزرگ می‌توانی فقط یک بازه خط درخواست کنی (start_line و end_line).",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "مسیر نسبی فایل"},
                    "start_line": {"type": "integer", "description": "(اختیاری) شماره خط شروع"},
                    "end_line": {"type": "integer", "description": "(اختیاری) شماره خط پایان"}
                },
                "required": ["path"]
            }
        }
    },
        {
        "type": "function",
        "function": {
            "name": "grep_file",
            "description": "جستجوی یک رشته در فایل و برگرداندن شماره خطوط. قبل از edit_file حتماً از این استفاده کن تا بدانی رشته دقیقاً در چه خطی هست.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "مسیر نسبی فایل"},
                    "pattern": {"type": "string", "description": "رشته‌ای که جستجو می‌شود"}
                },
                "required": ["path", "pattern"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "edit_file",
            "description": "جایگزینی یک رشته با رشته دیگر در فایل. برای فایل‌های موجود از این استفاده کن، نه write_file. old_string باید دقیقاً همان‌طور که در فایل هست باشد و فقط یک بار در فایل تکرار شده باشد.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "مسیر نسبی فایل"},
                    "old_string": {"type": "string", "description": "رشته دقیقی که باید پیدا شود"},
                    "new_string": {"type": "string", "description": "رشته جدید"}
                },
                "required": ["path", "old_string", "new_string"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "نوشتن یک فایل جدید. فقط برای فایل‌های جدیدی که از قبل وجود ندارند. برای فایل‌های موجود از edit_file استفاده کن.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "مسیر نسبی فایل"},
                    "content": {"type": "string", "description": "محتوای کامل فایل"}
                },
                "required": ["path", "content"]
            }
        }
    },

]

# ابزارهای مهندس پرامپت
prompt_engineer_tools = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "خواندن محتوای یک فایل از پروژه",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "مسیر نسبی فایل"}
                },
                "required": ["path"]
            }
        }
    }
]

def _find_file_smart(project_dir, path):
    """اگر فایل در مسیر دقیق نبود، در کل پوشه‌های زیرین می‌گردد"""
    exact_path = os.path.join(project_dir, path)
    if os.path.exists(exact_path):
        return exact_path
        
    # جستجوی هوشمند در زیرپوشه‌ها
    target_filename = os.path.basename(path)
    for root, dirs, files in os.walk(project_dir):
        if target_filename in files:
            # اگر مسیر نسبی باقی‌مانده هم مطابقت داشت، آن را برگردان
            found_rel = os.path.relpath(os.path.join(root, target_filename), project_dir).replace('\\', '/')
            if found_rel.endswith(path):
                return os.path.join(root, target_filename)
                
    return None # پیدا نشد
    
# =====================================================================
# ⚙️ توابع کمکی
# =====================================================================
def _safe_path(project_dir, path):
    """Resolve a project-relative path and reject traversal/symlink escapes."""
    project_root = os.path.realpath(project_dir)
    raw = str(path).replace("\\", "/").strip()
    project_name = os.path.basename(project_root)
    if raw.startswith(project_name + "/"):
        raw = raw[len(project_name) + 1:]
    if not raw or os.path.isabs(raw) or re.match(r"^[A-Za-z]:", raw):
        raise ValueError(f"مسیر نامعتبر است: {path}")
    full = os.path.realpath(os.path.join(project_root, raw))
    if os.path.commonpath([project_root, full]) != project_root:
        raise ValueError(f"مسیر '{path}' خارج از پروژه است.")
    return full


def _make_backup(full_path):
    """Keep per-file safety copies outside the game source tree."""
    workspace = os.path.realpath(WORKSPACE_DIR)
    current = os.path.realpath(os.path.dirname(full_path))
    while os.path.dirname(current) != workspace and current != workspace:
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent
    if os.path.commonpath([workspace, os.path.realpath(full_path)]) != workspace:
        raise ValueError("فایل برای بکاپ خارج از Workspace است")
    rel = os.path.relpath(full_path, current)
    project_name = os.path.basename(current)
    backup_root = os.path.join(workspace, ".file_backups", project_name)
    target = os.path.join(backup_root, rel + "." + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".bak")
    os.makedirs(os.path.dirname(target), exist_ok=True)
    shutil.copy2(full_path, target)


def read_file(project_dir, path, start_line=None, end_line=None):
    try:
        full_path = _safe_path(project_dir, path)
        if not os.path.exists(full_path):
            smart_path = _find_file_smart(project_dir, path)
            if smart_path:
                full_path = smart_path
    except ValueError as e:
        return f"❌ {e}"
        
    if not os.path.exists(full_path):
        return f"❌ فایل '{path}' پیدا نشد."
    try:
        with open(full_path, "r", encoding="utf-8") as f:
            content = f.read()
        
        # اگر بازه خطوط درخواست شده
        if start_line is not None or end_line is not None:
            lines = content.split('\n')
            total = len(lines)
            s = max(0, (start_line or 1) - 1)
            e = min(total, end_line or total)
            selected = "\n".join(lines[s:e])
            log_ui(f"   📖 خوانده شد: '{path}' (خطوط {s+1}-{e} از {total})")
            return f"[خطوط {s+1} تا {e} از {total}]\n{selected}"
        
        log_ui(f"   📖 خوانده شد: '{path}' ({len(content)} کاراکتر)")
        # فقط اگر خیلی بزرگ بود کوتاه کن
        if len(content) > 35000:
            return content[:35000] + "\n\n... [فایل بزرگ‌تر از ۳۵ هزار کاراکتر بود. از read_file با start_line/end_line برای دیدن بخش‌های دیگر استفاده کن]"
        return content
    except Exception as e:
        return f"❌ خطا در خواندن: {e}"

def grep_file(project_dir, path, pattern):
    try:
        full_path = _safe_path(project_dir, path)
    except ValueError as e:
        return f"❌ {e}"
    if not os.path.exists(full_path):
        return f"❌ فایل '{path}' پیدا نشد."
    try:
        with open(full_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception as e:
        return f"❌ خطا: {e}"
    
    matches = []
    for i, line in enumerate(lines, 1):
        if pattern in line:
            matches.append((i, line.rstrip()))
    
    if not matches:
        return f"❌ رشته '{pattern}' در '{path}' پیدا نشد. کلیدواژه دیگری امتحان کن."
    
    result = [f"📌 {len(matches)} مطابقت برای '{pattern}' در '{path}':"]
    for line_no, text in matches[:20]:
        # ۲ خط قبل و بعد برای context
        start = max(0, line_no - 3)
        end = min(len(lines), line_no + 2)
        result.append(f"\n--- خط {line_no} (با context) ---")
        for j in range(start, end):
            prefix = ">>>" if j == line_no - 1 else "   "
            result.append(f"{prefix} {j+1:4d}| {lines[j].rstrip()}")
    
    if len(matches) > 20:
        result.append(f"\n... و {len(matches) - 20} مطابقت دیگر")
    
    log_ui(f"   🔍 grep در '{path}': {len(matches)} مطابقت")
    return "\n".join(result)
    
    
def edit_file(project_dir, path, old_string, new_string):
    try:
        full_path = _safe_path(project_dir, path)
    except ValueError as e:
        return f"❌ {e}"
    
    if not os.path.exists(full_path):
        return f"❌ فایل '{path}' وجود ندارد. ابتدا read_file بزن."
    
    try:
        with open(full_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception as e:
        return f"❌ خطا در خواندن: {e}"
    
    if old_string not in content:
        return (
            f"❌ رشته مورد نظر در '{path}' پیدا نشد. "
            f"مطمئن شو دقیقاً همان‌طور که در فایل هست (با فاصله‌ها و خطوط) کپی کرده‌ای. "
            f"از read_file استفاده کن تا محتوای دقیق را ببینی."
        )
    
    count = content.count(old_string)
    if count > 1:
        return (
            f"⚠️ این رشته {count} بار در فایل تکرار شده. "
            f"رشته طولانی‌تری انتخاب کن که یکتا باشد."
        )
    
    new_content = content.replace(old_string, new_string, 1)
    
    _make_backup(full_path)
    
    temp_path = full_path + ".galab_tmp"
    with open(temp_path, "w", encoding="utf-8", newline="") as f:
        f.write(new_content)
        f.flush(); os.fsync(f.fileno())
    os.replace(temp_path, full_path)
    
    log_ui(f"   ✂️ ویرایش: '{path}' ({len(old_string)} → {len(new_string)} کاراکتر)")
    return f"✅ ویرایش انجام شد."


def write_file(project_dir, path, content):
    """Create a brand-new file only; never replace existing project files."""
    try:
        full_path = _safe_path(project_dir, path)
    except ValueError as e:
        return f"❌ {e}"
    if os.path.exists(full_path):
        return f"🚫 فایل '{path}' از قبل وجود دارد. write_file فقط برای فایل جدید مجاز است؛ برای فایل موجود از edit_file استفاده کن."
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    temp_path = full_path + ".galab_tmp"
    try:
        with open(temp_path, "x", encoding="utf-8", newline="") as f:
            f.write(content)
            f.flush(); os.fsync(f.fileno())
        if os.path.exists(full_path):
            os.remove(temp_path)
            return f"🚫 فایل '{path}' در حین ایجاد توسط عامل دیگری ساخته شد؛ چیزی بازنویسی نشد."
        os.replace(temp_path, full_path)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)
    log_ui(f"   💾 فایل جدید ساخته شد: '{path}' ({len(content)} کاراکتر)")
    return f"✅ فایل جدید '{path}' ذخیره شد."


def run_command(project_dir, command):
    """Shell execution is disabled by default to prevent destructive agent commands."""
    return "🚫 اجرای دستور Shell در GameAgentLab V2 به دلایل ایمنی غیرفعال است. برای بررسی کد از اعتبارسنج خودکار استفاده کن."


def split_file(project_dir, path, max_lines=250):
    """Retained only for compatibility with stale tool calls; never modifies files."""
    return "🚫 split_file در V2 حذف شده است. فایل اصلی دست‌نخورده می‌ماند؛ با read_file بازه‌ای بخوان."


def handle_tool_call(project_dir, tool_call):
    name = tool_call.function.name
    args = json.loads(tool_call.function.arguments)
    
    if name == "read_file":
        return read_file(
            project_dir, args["path"],
            args.get("start_line"), args.get("end_line")
        )
    elif name == "grep_file":
        return grep_file(project_dir, args["path"], args["pattern"])
    elif name == "edit_file":
        return edit_file(project_dir, args["path"], args["old_string"], args["new_string"])
    elif name == "write_file":
        return write_file(project_dir, args["path"], args["content"])
    elif name == "split_file":
        return split_file(project_dir, args["path"], args.get("max_lines", 250))
    elif name == "run_command":
        return run_command(project_dir, args["command"])
    return "ابزار ناشناخته"


def get_project_context(project_dir):
    """Build a compact manifest; let the model read only files relevant to its task."""
    if not os.path.exists(project_dir):
        return "پروژه خالی است."
    rows = ["--- ساختار و فهرست فایل‌های پروژه ---"]
    important = []
    for root, dirs, files in os.walk(project_dir):
        dirs[:] = sorted(d for d in dirs if d not in {'.git', 'node_modules', '__pycache__', '.backups', '.file_backups'})
        level = root.replace(project_dir, '').count(os.sep)
        rows.append('    ' * level + f"📁 {os.path.basename(root)}/")
        for name in sorted(files):
            if name.endswith(('.bak', '.original', '.galab_tmp')):
                continue
            full = os.path.join(root, name)
            rel = os.path.relpath(full, project_dir).replace('\\', '/')
            try:
                size = os.path.getsize(full)
                line_count = 0
                if name.lower().endswith(('.html', '.htm', '.js', '.css', '.py', '.json')):
                    with open(full, 'r', encoding='utf-8', errors='replace') as f:
                        line_count = sum(1 for _ in f)
                rows.append('    ' * (level + 1) + f"📄 {rel} ({size} bytes, {line_count} lines)")
                if rel.lower() in {'index.html', 'package.json', 'vite.config.js', 'webpack.config.js', 'readme.md'}:
                    important.append((rel, full))
            except OSError:
                rows.append('    ' * (level + 1) + f"📄 {rel} (unreadable)")
    rows.append("\n--- فایل‌های کلیدی (نمونه محدود) ---")
    for rel, full in important[:5]:
        try:
            with open(full, 'r', encoding='utf-8', errors='replace') as f:
                snippet = f.read(10000)
            rows.append(f"\n--- FILE: {rel} ---\n{snippet}")
        except OSError:
            pass
    rows.append("\nبرای فایل‌های دیگر از read_file استفاده کن و فقط بخش مرتبط با وظیفه را بخوان؛ تمام سورس‌ها را بی‌دلیل وارد Context نکن.")
    return '\n'.join(rows)


def list_project_files(project_dir):
    files = []
    for root, dirs, fs in os.walk(project_dir):
        dirs[:] = [d for d in dirs if d not in {'.git', 'node_modules', '__pycache__', '.backups', '.file_backups'}]
        for f in fs:
            if f.endswith('.bak') or f.endswith('.original'):
                continue
            files.append(os.path.relpath(os.path.join(root, f), project_dir).replace("\\", "/"))
    return files


def analyze_mission_logs(log_text, project_name=None):
    """Ask the configured LM Studio model to diagnose console/mission logs."""
    clean_logs = str(log_text or '').strip()
    if not clean_logs:
        raise ValueError("لاگی برای تحلیل دریافت نشد.")
    if len(clean_logs) > 30000:
        clean_logs = clean_logs[-30000:]
    system_message = """تو یک مهندس ارشد دیباگ نرم‌افزار و تحلیل‌گر لاگ هستی. لاگ‌های GameAgentLab را بررسی کن.
فقط تحلیل کن؛ هیچ فایلی را تغییر نده و ابزار اجرا نکن.
پاسخ را به فارسی و با این بخش‌ها بنویس:
1) خلاصه اتفاق و مرحله شکست
2) علت اصلی خطا با استناد به خطوط واقعی لاگ؛ اگر قطعی نیست، احتمالی اعلام کن
3) راهکار اصلاح مرحله‌به‌مرحله و فایل/تابع محتمل، فقط در صورت وجود شواهد
4) فایل‌ها، توابع و وابستگی‌هایی که عامل کدنویس باید پیش از تغییر بخواند
5) تست‌های لازم پس از اصلاح و معیار موفقیت
6) وضعیت Rollback، اگر در لاگ مشخص است
هرگز لاگ یا شواهد جعل نکن. اگر شواهد ناکافی است، اطلاعات کمبود را دقیق اعلام کن. فقط در صورت شواهد روشن، مشکل را به خود GameAgentLab/agent.py نسبت بده."""
    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": system_message},
            {"role": "user", "content": f"پروژه: {project_name or 'نامشخص'}\nمدل: {MODEL_NAME}\n\nلاگ کنسول:\n{clean_logs}"}
        ],
        temperature=0.2,
        max_tokens=2200
    )
    analysis = response.choices[0].message.content
    if not analysis or not analysis.strip():
        raise RuntimeError("مدل LM Studio پاسخ تحلیلی خالی برگرداند.")
    return analysis.strip()


def validate_vision_image_data_url(data_url):
    """Validate a browser-provided PNG/JPEG/WebP data URL and enforce a byte limit."""
    if data_url in (None, ""):
        return None
    if not isinstance(data_url, str):
        raise ValueError("داده تصویر نامعتبر است.")
    match = re.fullmatch(r"data:(image/(?:png|jpeg|webp));base64,([A-Za-z0-9+/]*={0,2})", data_url)
    if not match:
        raise ValueError("فرمت تصویر نامعتبر است؛ فقط PNG، JPG و WEBP پشتیبانی می‌شوند.")
    mime_type, encoded = match.groups()
    max_encoded = 4 * ((MAX_VISION_IMAGE_BYTES + 2) // 3)
    if len(encoded) > max_encoded:
        raise ValueError("حجم تصویر بیشتر از حد مجاز ۱۲ مگابایت است.")
    try:
        image_bytes = base64.b64decode(encoded, validate=True)
    except (ValueError, base64.binascii.Error) as exc:
        raise ValueError("کدگذاری Base64 تصویر معتبر نیست.") from exc
    if not image_bytes or len(image_bytes) > MAX_VISION_IMAGE_BYTES:
        raise ValueError("حجم تصویر خالی یا بیشتر از حد مجاز ۱۲ مگابایت است.")

    signatures = {
        "image/png": image_bytes.startswith(b"\x89PNG\r\n\x1a\n"),
        "image/jpeg": image_bytes.startswith(b"\xff\xd8\xff"),
        "image/webp": len(image_bytes) >= 12 and image_bytes[:4] == b"RIFF" and image_bytes[8:12] == b"WEBP",
    }
    if not signatures.get(mime_type, False):
        raise ValueError("محتوای فایل با فرمت اعلام‌شده تصویر مطابقت ندارد.")
    return data_url


def analyze_vision_image(image_data_url, user_request):
    """Analyze an image through LM Studio's native REST API, avoiding the
    OpenAI-compatible image_url data-URI parsing bug found in some LM Studio builds.
    Returns a text description that can be passed to the existing tool-enabled
    prompt-engineering chat completion flow.
    """
    image_data_url = validate_vision_image_data_url(image_data_url)
    if not image_data_url:
        raise ValueError("تصویر مرجعی برای تحلیل دریافت نشد.")
    if http_client is None:
        raise RuntimeError("کتابخانه httpx نصب نیست؛ requirements را نصب یا به‌روزرسانی کن.")

    system_prompt = """تو یک تحلیل‌گر بینایی و متخصص دارایی‌های بازی هستی.
تصویر ارسالی را با دقت و فقط بر اساس جزئیات قابل مشاهده تحلیل کن.
به فارسی گزارش بده و این موارد را پوشش بده:
- شکل کلی، نسبت ابعاد، زاویه دید و سیلوئت
- اجزای اصلی و فرعی و محل قرارگیری آن‌ها
- رنگ‌ها، جنس ظاهری، بافت، نور، سایه و جزئیات شاخص
- ویژگی‌هایی که برای بازسازی در بازی دوبعدی/Canvas یا Sprite باید حفظ شوند
- اندازه و وضوح مناسب پیشنهادی، بدون ادعای اینکه فایلی ساخته شده است
مشاهدات قطعی را از حدس‌ها جدا کن. جزئیات نامشخص را جعل نکن.
هدف این است که تحلیل به مشخصات اجرایی قابل استفاده برای یک عامل کدنویس تبدیل شود."""
    user_text = (
        f"درخواست کاربر: {user_request}\n\n"
        "تصویر پیوست‌شده مرجع بصری این درخواست است. ظاهر آن را توصیف کن و مشخصات "
        "دقیق و قابل پیاده‌سازی استخراج کن."
    )
    payload = {
        "model": MODEL_NAME,
        "input": [
            {"type": "image", "data_url": image_data_url},
            {"type": "text", "content": user_text},
        ],
        "system_prompt": system_prompt,
        "temperature": 0.2,
        "max_output_tokens": 1800,
        "store": False,
    }
    try:
        response = http_client.post(LM_STUDIO_NATIVE_CHAT_URL, json=payload)
        response.raise_for_status()
        body = response.json()
    except Exception as exc:
        detail = ""
        response_obj = getattr(exc, "response", None)
        if response_obj is not None:
            try:
                detail = response_obj.text[:1500]
            except Exception:
                detail = ""
        extra = f" | جزئیات سرور: {detail}" if detail else ""
        raise RuntimeError(
            f"ارسال تصویر از API بومی LM Studio ناموفق بود ({exc}). "
            f"آدرس موردنیاز: {LM_STUDIO_NATIVE_CHAT_URL}. "
            "نسخه LM Studio باید API بومی /api/v1/chat را پشتیبانی کند و مدل Vision بارگذاری شده باشد."
            + extra
        ) from exc

    output_items = body.get("output", []) if isinstance(body, dict) else []
    message_parts = [
        str(item.get("content", "")).strip()
        for item in output_items
        if isinstance(item, dict) and item.get("type") == "message" and item.get("content")
    ]
    analysis = "\n\n".join(part for part in message_parts if part).strip()
    if not analysis:
        raise RuntimeError("LM Studio تصویر را دریافت کرد اما پاسخ متنی قابل استفاده‌ای برنگرداند.")
    return analysis


def build_prompt_user_content(user_request, file_tree, vision_analysis=None):
    """Create text-only content for the tool-enabled prompt-engineer pass."""
    text_content = (
        f"درخواست کاربر: {user_request}\n\n"
        f"لیست فایل‌ها:\n{file_tree}\n\n"
    )
    if vision_analysis:
        text_content += (
            "--- تحلیل تصویری استخراج‌شده از تصویر مرجع توسط LM Studio Vision ---\n"
            + vision_analysis
            + "\n--- پایان تحلیل تصویری ---\n\n"
            "از این تحلیل به‌عنوان مشخصات مرجع بصری استفاده کن. آن را با ساختار واقعی پروژه "
            "تطبیق بده و فایل‌های مرتبط را با read_file بررسی کن."
        )
    text_content += (
        "ابتدا با read_file فایل‌های مرتبط را بررسی کن، سپس پرامپت نهایی را بنویس. "
        "اگر تحلیل تصویری پیوست شده، جزئیات قابل مشاهده آن را به مشخصات اجرایی تبدیل کن؛ "
        "فرض نکن تصویر خودکار داخل پروژه ذخیره شده است."
    )
    return text_content


def generate_prompt(user_request, project_dir, image_data_url=None):
    file_list = list_project_files(project_dir)
    tree = "\n".join(file_list) if file_list else "(خالی)"
    image_data_url = validate_vision_image_data_url(image_data_url)
    vision_analysis = None
    if image_data_url:
        log_ui("👁️ تصویر مرجع برای تحلیل اولیه از API بومی LM Studio ارسال می‌شود...")
        vision_analysis = analyze_vision_image(image_data_url, user_request)
        log_ui("✅ تحلیل تصویری دریافت شد؛ اکنون مهندس پرامپت ساختار پروژه را بررسی می‌کند...")

    messages = [
        {"role": "system", "content": PROMPT_ENGINEER_SYSTEM},
        {"role": "user", "content": build_prompt_user_content(user_request, tree, vision_analysis)}
    ]
    
    for _ in range(6):
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=messages,
                tools=prompt_engineer_tools,
                tool_choice="auto",
                temperature=0.3,
                max_tokens=4000
            )
        except Exception as e:
            if image_data_url:
                return ("❌ خطا در تولید پرامپت پس از تحلیل تصویر: " + str(e) +
                        "\nابتدا خطای API بومی Vision را بررسی کن؛ سپس مطمئن شو Local Server فعال و مدل Vision بارگذاری شده است.")
            return f"❌ خطا در ارتباط با LM Studio: {e}"
        
        msg = response.choices[0].message
        messages.append(msg)
        
        if msg.tool_calls:
            for tc in msg.tool_calls:
                args = json.loads(tc.function.arguments)
                path = args.get("path", "")
                try:
                    full = _safe_path(project_dir, path)
                    if not os.path.exists(full):
                        result = f"❌ فایل '{path}' پیدا نشد."
                    else:
                        with open(full, 'r', encoding='utf-8') as f:
                            content = f.read()
                        if len(content) > 12000:
                            content = content[:12000] + "\n... [کوتاه شد]"
                        result = content
                except Exception as e:
                    result = f"❌ خطا: {e}"
                messages.append({"role": "tool", "tool_call_id": tc.id, "content": result})
        else:
            return msg.content.strip() if msg.content else "❌ مدل پاسخ خالی داد."
    
    return "❌ نتوانستم پرامپت تولید کنم."


def _project_html_root(project_dir):
    """Find the actual web-game root even when ZIP contains one wrapper folder."""
    if os.path.isfile(os.path.join(project_dir, "index.html")):
        return project_dir
    candidates = []
    for root, dirs, files in os.walk(project_dir):
        dirs[:] = [d for d in dirs if d not in {".git", "node_modules", "__pycache__", ".backups"}]
        if "index.html" in files:
            candidates.append(root)
    return candidates[0] if len(candidates) == 1 else project_dir


def _snapshot_project(project_dir):
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_root = os.path.join(WORKSPACE_DIR, ".backups", os.path.basename(project_dir))
    os.makedirs(backup_root, exist_ok=True)
    snapshot = os.path.join(backup_root, stamp)
    shutil.copytree(project_dir, snapshot, ignore=shutil.ignore_patterns("*.bak", "*.original", "__pycache__"))
    log_ui(f"🛡️ نسخه پشتیبان مأموریت ساخته شد: {os.path.relpath(snapshot, WORKSPACE_DIR)}")
    return snapshot


def _restore_snapshot(project_dir, snapshot):
    failed_root = os.path.join(WORKSPACE_DIR, ".failed_runs")
    os.makedirs(failed_root, exist_ok=True)
    failed = os.path.join(failed_root, os.path.basename(project_dir) + "_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
    if os.path.exists(project_dir):
        os.replace(project_dir, failed)
    shutil.copytree(snapshot, project_dir)
    log_ui(f"↩️ تغییرات ناموفق برگشت داده شد. نسخه ناموفق برای عیب‌یابی نگهداری شد: {os.path.basename(failed)}")


def _collect_validation_issues(project_dir):
    """Static checks; reports existing baseline issues separately from new regressions."""
    import html.parser
    issues = []
    root = _project_html_root(project_dir)
    class RefParser(html.parser.HTMLParser):
        def __init__(self):
            super().__init__(); self.refs = []
        def handle_starttag(self, tag, attrs):
            a = dict(attrs)
            if tag == "script" and a.get("src"):
                self.refs.append(a["src"])
            if tag == "link" and a.get("href") and (a.get("rel", "").lower() == "stylesheet"):
                self.refs.append(a["href"])
    html_files = []
    for r, ds, fs in os.walk(root):
        ds[:] = [d for d in ds if d not in {"node_modules", ".git", "__pycache__"}]
        html_files.extend(os.path.join(r, f) for f in fs if f.lower().endswith((".html", ".htm")))
    for html_path in html_files:
        rel_html = os.path.relpath(html_path, root)
        try:
            parser = RefParser(); parser.feed(Path(html_path).read_text(encoding="utf-8", errors="replace"))
            for ref in parser.refs:
                ref = ref.split("?", 1)[0].split("#", 1)[0]
                if not ref or re.match(r"^(https?:|data:|//|#)", ref, re.I):
                    continue
                candidate = os.path.realpath(os.path.join(os.path.dirname(html_path), urllib.parse.unquote(ref)))
                if os.path.commonpath([os.path.realpath(root), candidate]) != os.path.realpath(root):
                    issues.append(f"HTML path escapes project: {rel_html} -> {ref}")
                elif not os.path.isfile(candidate):
                    issues.append(f"Missing asset: {rel_html} -> {ref}")
        except Exception as e:
            issues.append(f"HTML parse/read issue: {rel_html}: {e}")
    node = shutil.which("node")
    if node:
        for r, ds, fs in os.walk(root):
            ds[:] = [d for d in ds if d not in {"node_modules", ".git", "__pycache__"}]
            for name in fs:
                if name.lower().endswith(".js"):
                    path = os.path.join(r, name)
                    try:
                        result = subprocess.run([node, "--check", path], capture_output=True, text=True, timeout=20)
                        if result.returncode:
                            msg = (result.stderr or result.stdout).strip().splitlines()
                            issues.append(f"JavaScript syntax: {os.path.relpath(path, root)}: {' | '.join(msg[:3])}")
                    except Exception as e:
                        issues.append(f"JavaScript check skipped: {name}: {e}")
    else:
        log_ui("ℹ️ Node.js پیدا نشد؛ بررسی Syntax جاوااسکریپت رد شد. برای این تست Node.js نصب باشد.")
    return issues


def validate_project(project_dir, baseline):
    current = _collect_validation_issues(project_dir)
    new_issues = [x for x in current if x not in baseline]
    if current:
        log_ui(f"🔎 اعتبارسنجی: {len(current)} هشدار/ایراد فعلی؛ {len(new_issues)} مورد جدید")
        for issue in current[:30]:
            log_ui(("❌ " if issue in new_issues else "⚠️ موجود از قبل: ") + issue)
    else:
        log_ui("✅ اعتبارسنجی ایستا بدون ایراد انجام شد.")
    return new_issues, current


def run_agent_loop(goal, project_name, max_iterations=30):
    global is_running, MISSION_LOG_PATH
    if is_running:
        log_ui("⚠️ یک مأموریت دیگر در حال اجراست.")
        return
    is_running = True
    project_dir = os.path.join(WORKSPACE_DIR, project_name)
    snapshot = None
    mission_log_dir = os.path.join(WORKSPACE_DIR, ".mission_logs", project_name)
    os.makedirs(mission_log_dir, exist_ok=True)
    MISSION_LOG_PATH = os.path.join(mission_log_dir, datetime.now().strftime("%Y%m%d_%H%M%S") + ".log")
    log_ui(f"\n🚀 شروع مأموریت V2 روی '{project_name}': {goal}\n")
    try:
        snapshot = _snapshot_project(project_dir)
        baseline = _collect_validation_issues(project_dir)
        log_ui(f"📋 اسکن اولیه انجام شد؛ {len(baseline)} هشدار پایه ثبت شد.")
        existing_context = get_project_context(project_dir)
        user_prompt = f"دستور کاربر: {goal}\n\n--- وضعیت فعلی پروژه ---\n{existing_context}\n\nقوانین V2: فایل‌ها را split نکن. write_file فقط برای فایل جدید است. پس از هر edit_file تغییر را بخوان و فقط فایل‌های مرتبط را دستکاری کن."
        messages = [{"role": "system", "content": FIXED_PROMPT}, {"role": "user", "content": user_prompt}]
        completed = False
        for i in range(max_iterations):
            log_ui(f"\n--- 🔄 تکرار {i+1}/{max_iterations} ---")
            try:
                response = client.chat.completions.create(model=MODEL_NAME, messages=messages, tools=tools,
                    tool_choice="auto", temperature=0.1, max_tokens=8000)
            except Exception as e:
                log_ui(f"❌ خطا در ارتباط با LM Studio: {e}")
                break
            msg = response.choices[0].message
            messages.append(msg)
            if msg.tool_calls:
                for tool_call in msg.tool_calls:
                    log_ui(f"🛠️ ابزار: {tool_call.function.name}")
                    try:
                        result = handle_tool_call(project_dir, tool_call)
                    except Exception as e:
                        result = f"❌ خطای ابزار: {e}"
                    log_ui(f"   ↳ {str(result)[:240]}")
                    messages.append({"role": "tool", "tool_call_id": tool_call.id, "content": str(result)})
            else:
                log_ui(f"🤖 مدل: {msg.content or '(پاسخ خالی)'}")
                if msg.content and "پایان" in msg.content:
                    completed = True
                    break
                messages.append({"role": "user", "content": "کار را با ابزارهای مجاز ادامه بده. split_file ممنوع است. در پایان بنویس 'پایان'."})
        if not completed:
            log_ui("🛑 مأموریت کامل نشد؛ برای جلوگیری از تحویل تغییرات نیمه‌کاره، Rollback انجام می‌شود.")
            _restore_snapshot(project_dir, snapshot)
        else:
            new_issues, all_issues = validate_project(project_dir, baseline)
            if new_issues:
                _restore_snapshot(project_dir, snapshot)
                log_ui("🛑 مأموریت رد شد: خطای جدید نسبت به وضعیت اولیه ایجاد شده بود؛ پروژه به نسخه قبل برگشت.")
            else:
                log_ui("✅ تغییرات از بررسی‌های ایستا عبور کردند. پیش‌نمایش دستی بازی همچنان توصیه می‌شود.")
                log_ui("📦 اکنون می‌توانی ZIP پروژه را دانلود و تست کنی.")
    except Exception as e:
        log_ui(f"❌ خطای مدیریت مأموریت: {e}")
        if snapshot and os.path.isdir(snapshot):
            try: _restore_snapshot(project_dir, snapshot)
            except Exception as restore_error: log_ui(f"❌ Rollback ناموفق: {restore_error}")
    finally:
        is_running = False
        log_ui("\n⏹️ مأموریت V2 پایان یافت.\n")
        MISSION_LOG_PATH = None


# =====================================================================
# 🌐 وب‌سرور
# =====================================================================
class AgentHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        global CURRENT_PROJECT
        parsed_path = urllib.parse.urlparse(self.path).path
        
        if parsed_path == "/health":
            payload = {"version": "2.2.1", "model": MODEL_NAME, "lm_studio": LM_STUDIO_URL, "node_available": bool(shutil.which("node"))}
            self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers()
            self.wfile.write(json.dumps(payload).encode("utf-8")); return
        if parsed_path == "/list_projects":
            projects = [d for d in os.listdir(WORKSPACE_DIR) if not d.startswith(".") and os.path.isdir(os.path.join(WORKSPACE_DIR, d))] if os.path.exists(WORKSPACE_DIR) else []
            
            if CURRENT_PROJECT and not os.path.exists(os.path.join(WORKSPACE_DIR, CURRENT_PROJECT)):
                CURRENT_PROJECT = None
            
            if CURRENT_PROJECT is None and projects:
                try:
                    projects_sorted = sorted(projects, key=lambda p: os.path.getmtime(os.path.join(WORKSPACE_DIR, p)), reverse=True)
                    CURRENT_PROJECT = projects_sorted[0]
                    projects = projects_sorted
                except Exception as e:
                    print(f"⚠️ auto-select: {e}")
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"projects": projects, "current": CURRENT_PROJECT}).encode())
            return
        
        elif parsed_path == "/logs":
            with log_lock:
                data = json.dumps({"logs": agent_logs, "running": is_running, "current": CURRENT_PROJECT})
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(data.encode())
            return
        
        elif parsed_path == "/list_files":
            file_list = []
            if CURRENT_PROJECT:
                proj_dir = os.path.join(WORKSPACE_DIR, CURRENT_PROJECT)
                if os.path.exists(proj_dir):
                    for root, dirs, files in os.walk(proj_dir):
                        for file in files:
                            if not file.endswith(('.bak', '.original', '.galab_tmp', '.pyc')) and file != '.DS_Store':
                                file_list.append(os.path.relpath(os.path.join(root, file), proj_dir).replace("\\", "/"))
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(file_list).encode())
            return
        
        elif parsed_path == "/download":
            if not CURRENT_PROJECT:
                return self.send_error(400, "No project selected")
            try:
                proj_dir = os.path.join(WORKSPACE_DIR, CURRENT_PROJECT)
                memory_file = io.BytesIO()
                with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
                    for root, dirs, files in os.walk(proj_dir):
                        for file in files:
                            if not file.endswith(('.bak', '.original', '.galab_tmp', '.pyc')) and file != '.DS_Store':
                                file_path = os.path.join(root, file)
                                zf.write(file_path, os.path.relpath(file_path, proj_dir))
                memory_file.seek(0)
                self.send_response(200)
                self.send_header('Content-Type', 'application/zip')
                self.send_header('Content-Disposition', f'attachment; filename="{CURRENT_PROJECT}.zip"')
                self.end_headers()
                self.wfile.write(memory_file.read())
            except Exception as e:
                self.send_error(500, str(e))
            return
        
        elif parsed_path.startswith("/game/"):
            if not CURRENT_PROJECT:
                return self.send_error(404, "No project selected")
            game_path = parsed_path.replace("/game/", "", 1)
            if not game_path or game_path == "/":
                game_path = "index.html"
            
            proj_dir = os.path.join(WORKSPACE_DIR, CURRENT_PROJECT)
            full_path = os.path.join(proj_dir, game_path)
            
            if os.path.exists(full_path) and os.path.isfile(full_path):
                self.send_response(200)
                if full_path.endswith(".html"):
                    self.send_header('Content-Type', 'text/html; charset=utf-8')
                elif full_path.endswith(".css"):
                    self.send_header('Content-Type', 'text/css')
                elif full_path.endswith(".js"):
                    self.send_header('Content-Type', 'application/javascript')
                self.end_headers()
                with open(full_path, 'rb') as f:
                    self.wfile.write(f.read())
            else:
                self.send_error(404, "File not found")
            return
        
        if parsed_path == "/":
            self.path = "/index.html"
        return super().do_GET()
    
    def do_POST(self):
        global CURRENT_PROJECT
        
        if self.path == "/select_project":
            content_length = int(self.headers['Content-Length'])
            data = json.loads(self.rfile.read(content_length))
            selected = str(data.get("project") or "")
            if not selected or os.path.basename(selected) != selected or selected.startswith("."):
                self.send_response(400); self.end_headers(); return
            candidate = os.path.join(WORKSPACE_DIR, selected)
            if not os.path.isdir(candidate):
                self.send_response(404); self.end_headers(); return
            CURRENT_PROJECT = selected
            log_ui(f"\n🔄 پروژه فعال: {CURRENT_PROJECT}")
            self.send_response(200)
            self.end_headers()
            return
        
        if self.path == "/clear_current":
            if CURRENT_PROJECT:
                proj_dir = os.path.join(WORKSPACE_DIR, CURRENT_PROJECT)
                if os.path.exists(proj_dir):
                    shutil.rmtree(proj_dir)
                    log_ui(f"\n🧹 پروژه '{CURRENT_PROJECT}' پاک شد.")
                CURRENT_PROJECT = None
            self.send_response(200)
            self.end_headers()
            return
        
        if self.path == "/upload":
            content_length = int(self.headers['Content-Length'])
            data = json.loads(self.rfile.read(content_length))
            
            if "file" in data and "filename" in data:
                raw_name = data["filename"].rsplit('.', 1)[0]
                safe_name = "".join([c if c.isalnum() or c in "_-" else "_" for c in raw_name]).strip("_")
                if not safe_name:
                    self.send_response(400); self.end_headers(); return
                
                new_proj_dir = os.path.join(WORKSPACE_DIR, safe_name)
                staging = os.path.join(WORKSPACE_DIR, f".upload_{safe_name}_{datetime.now().strftime('%H%M%S%f')}")
                os.makedirs(staging, exist_ok=False)
                try:
                    encoded = data["file"].split(",", 1)[-1]
                    if len(encoded) > 280_000_000:
                        raise ValueError("حجم ZIP بیش از حد مجاز است (حدود 200MB).")
                    file_bytes = base64.b64decode(encoded, validate=True)
                    with zipfile.ZipFile(io.BytesIO(file_bytes), 'r') as zf:
                        infos = zf.infolist()
                        if len(infos) > 10000:
                            raise ValueError("تعداد فایل‌های ZIP بیش از حد مجاز است.")
                        if sum(i.file_size for i in infos) > 500_000_000:
                            raise ValueError("حجم استخراج‌شده ZIP بیش از 500MB است.")
                        for info in infos:
                            name = info.filename.replace("\\", "/")
                            parts = [x for x in name.split("/") if x not in ("", ".")]
                            if name.startswith("/") or not parts or ".." in parts or (len(parts[0]) > 1 and parts[0][1] == ":"):
                                raise ValueError(f"مسیر ناامن در ZIP: {info.filename}")
                            target = os.path.realpath(os.path.join(staging, *parts))
                            if os.path.commonpath([os.path.realpath(staging), target]) != os.path.realpath(staging):
                                raise ValueError(f"مسیر خارج از ZIP: {info.filename}")
                            if info.is_dir(): os.makedirs(target, exist_ok=True); continue
                            os.makedirs(os.path.dirname(target), exist_ok=True)
                            with zf.open(info) as src, open(target, "wb") as dst:
                                shutil.copyfileobj(src, dst)
                    # Flatten the common single-wrapper-folder ZIP layout.
                    entries = os.listdir(staging)
                    if len(entries) == 1 and os.path.isdir(os.path.join(staging, entries[0])) and os.path.isfile(os.path.join(staging, entries[0], "index.html")):
                        wrapper = os.path.join(staging, entries[0])
                        extracted = os.path.join(staging, "_flattened")
                        os.replace(wrapper, extracted)
                        for item in os.listdir(extracted): os.replace(os.path.join(extracted, item), os.path.join(staging, item))
                        shutil.rmtree(extracted)
                    if not any(os.path.isfile(os.path.join(r, f)) for r, _, fs in os.walk(staging) for f in fs):
                        raise ValueError("ZIP خالی است")
                    if os.path.exists(new_proj_dir):
                        archived = os.path.join(WORKSPACE_DIR, ".upload_replaced")
                        os.makedirs(archived, exist_ok=True)
                        os.replace(new_proj_dir, os.path.join(archived, safe_name + "_" + datetime.now().strftime('%Y%m%d_%H%M%S')))
                    os.replace(staging, new_proj_dir)
                    CURRENT_PROJECT = safe_name
                    log_ui(f"\n📥 پروژه '{safe_name}' به‌صورت امن آپلود شد؛ فایل‌های قدیمی با ZIP جدید مخلوط نشدند.")
                    self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers()
                    self.wfile.write(json.dumps({"project": safe_name}, ensure_ascii=False).encode("utf-8"))
                except Exception as e:
                    shutil.rmtree(staging, ignore_errors=True)
                    self.send_response(400); self.send_header('Content-Type', 'application/json'); self.end_headers()
                    self.wfile.write(json.dumps({"error": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        
        if self.path == "/run":
            content_length = int(self.headers['Content-Length'])
            data = json.loads(self.rfile.read(content_length))
            if not CURRENT_PROJECT:
                self.send_response(400)
                self.end_headers()
                return
            
            if not is_running:
                with log_lock:
                    agent_logs.clear()
                threading.Thread(target=run_agent_loop,
                                 args=(data.get("goal", ""), CURRENT_PROJECT),
                                 daemon=True).start()
            self.send_response(200)
            self.end_headers()
            return
        
        if self.path == "/analyze_logs":
            try:
                content_length = int(self.headers.get('Content-Length', '0'))
                if content_length <= 0 or content_length > 100000:
                    raise ValueError("اندازه درخواست لاگ نامعتبر است.")
                data = json.loads(self.rfile.read(content_length))
                log_text = str(data.get("logs", ""))
                if not log_text.strip():
                    raise ValueError("لاگی برای تحلیل دریافت نشد.")
                analysis = analyze_mission_logs(log_text, CURRENT_PROJECT)
                log_ui("🧠 تحلیل لاگ توسط LM Studio تکمیل شد؛ نتیجه برای تولید پرامپت آماده است.")
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(json.dumps({"analysis": analysis}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self.send_response(502 if not isinstance(e, ValueError) else 400)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}, ensure_ascii=False).encode("utf-8"))
            return

        if self.path == "/generate_prompt":
            try:
                content_length = int(self.headers.get('Content-Length', '0'))
                if content_length <= 0 or content_length > MAX_PROMPT_REQUEST_BYTES:
                    raise ValueError("اندازه درخواست تولید پرامپت نامعتبر یا بیش از ۱۸ مگابایت است.")
                data = json.loads(self.rfile.read(content_length))
                user_request = str(data.get("request", "")).strip()
                image_data_url = validate_vision_image_data_url(data.get("image_data_url"))
            except Exception as e:
                self.send_response(400)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}, ensure_ascii=False).encode("utf-8"))
                return
            
            if not CURRENT_PROJECT or not user_request:
                self.send_response(400)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"error": "درخواست خالی یا پروژه انتخاب نشده"}).encode())
                return
            
            try:
                proj_dir = os.path.join(WORKSPACE_DIR, CURRENT_PROJECT)
                prompt = generate_prompt(user_request, proj_dir, image_data_url=image_data_url)
                if isinstance(prompt, str) and prompt.startswith("❌"):
                    raise RuntimeError(prompt)
                if image_data_url:
                    image_mime = image_data_url.split(';', 1)[0][5:]
                    log_ui(f"👁️ تصویر مرجع ({image_mime}) با API بومی LM Studio تحلیل شد و خلاصه آن به مهندس پرامپت رسید.")
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"prompt": prompt}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self.send_response(500)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return


if __name__ == "__main__":
    os.chdir(BASE_DIR)
    os.makedirs(WORKSPACE_DIR, exist_ok=True)
    
    if os.path.exists(WORKSPACE_DIR):
        _projects = [d for d in os.listdir(WORKSPACE_DIR) if not d.startswith(".") and os.path.isdir(os.path.join(WORKSPACE_DIR, d))]
        if _projects:
            _projects.sort(key=lambda p: os.path.getmtime(os.path.join(WORKSPACE_DIR, p)), reverse=True)
            CURRENT_PROJECT = _projects[0]
            print(f"📂 پروژه خودکار: {CURRENT_PROJECT}")
    
    server = ThreadingHTTPServer((SERVER_HOST, SERVER_PORT), AgentHandler)
    print(f"🌐 GameAgentLab V2 server: http://localhost:{SERVER_PORT}")
    print(f"🔎 Version check: http://localhost:{SERVER_PORT}/health")
    server.serve_forever()