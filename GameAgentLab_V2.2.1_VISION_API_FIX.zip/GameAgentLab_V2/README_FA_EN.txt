GAMEAGENTLAB V2.2.1 - VARAGOD
========================================

فارسی | راه‌اندازی در Windows 10/11
----------------------------------------
1) پوشه GameAgentLab_V2 را از ZIP خارج کن.
2) مطمئن شو Python 3.10 یا جدیدتر نصب است و گزینه Add Python to PATH فعال بوده.
3) LM Studio نسخه 0.4.0 یا جدیدتر را اجرا کن تا API بومی `/api/v1/chat` در دسترس باشد.
4) مدل google/gemma-4-e4b را با پشتیبانی Vision بارگذاری کن.
5) در LM Studio وارد Local Server شو، سرور را روی 127.0.0.1:1234 اجرا کن.
6) فایل start_gameagentlab_v2.bat را دوبار کلیک کن.
7) اولین اجرا ممکن است برای نصب کتابخانه‌ها به اینترنت نیاز داشته باشد.
8) مرورگر را در آدرس http://localhost:8001 باز کن.
9) ZIP بازی را آپلود کن، پروژه را انتخاب کن، پرامپت بساز و سپس مأموریت را اجرا کن.
10) پس از پایان، لاگ را بخوان و ZIP خروجی را دانلود کن. بازی را در مرورگر تست کن.
11) اگر مأموریت خطا داد، در کنسول زنده روی «🧠 تحلیل لاگ» بزن. مدل LM Studio علت و راهکار را بررسی می‌کند و نتیجه را به‌صورت خودکار وارد تولید پرامپت اصلاحی می‌کند.
12) برای ارسال تصویر مرجع، در سربرگ «تولید پرامپت» روی VISION بزن، تصویر PNG/JPG/WEBP را انتخاب کن، متن درخواست را بنویس و سپس «تولید پرامپت» را بزن. تصویر و متن با هم از API بومی LM Studio در مسیر `/api/v1/chat` برای تحلیل بصری ارسال می‌شوند؛ سپس خلاصه تحلیل به مهندس پرامپت ابزارمحور داده می‌شود. حداکثر اندازه تصویر ۱۲ مگابایت است.

نکات مهم:
- مدل پیش‌فرض همان google/gemma-4-e4b است و آدرس LM Studio در ابتدای agent.py قابل تغییر است.
- V2 قبل از هر مأموریت یک Snapshot کامل در workspace/.backups می‌سازد.
- اگر Agent بدون اعلام «پایان» متوقف شود، تغییرات نیمه‌کاره Rollback می‌شوند.
- اگر اعتبارسنجی، خطای جدید JavaScript یا ارجاع جدید به فایل مفقود پیدا کند، تغییرات Rollback می‌شوند.
- ایرادهایی که از قبل در پروژه وجود داشته‌اند به‌عنوان هشدار پایه ثبت می‌شوند و به‌تنهایی باعث Rollback نمی‌شوند.
- split_file عمداً غیرفعال شده است؛ تقسیم متنی فایل JS ممکن است Scope و ترتیب اجرا را خراب کند.
- write_file فقط برای فایل جدید است؛ برای فایل موجود باید از edit_file استفاده شود.
- اجرای Shell از طریق Agent عمداً غیرفعال است تا دستورات مخرب اجرا نشوند.
- بکاپ‌ها خارج از پوشه بازی نگهداری می‌شوند و وارد ZIP تحویلی بازی نمی‌شوند.
- اعتبارسنجی ایستا تضمین اجرای کامل بازی نیست. بعد از هر تغییر، Preview را باز کن و گیم‌پلی را دستی هم تست کن.
- برای بررسی Syntax جاوااسکریپت، نصب Node.js توصیه می‌شود. اگر Node.js نصب نباشد، این تست رد می‌شود و در لاگ اعلام خواهد شد.
- اجرای برنامه فقط روی همین کامپیوتر و localhost تنظیم شده است؛ آن را بدون احراز هویت روی شبکه عمومی منتشر نکن.
- تحلیل‌گر لاگ فقط تشخیص می‌دهد و فایل‌ها را تغییر نمی‌دهد؛ پرامپت اصلاحی تولید می‌کند تا Agent آن را اجرا کند. برای تحلیل، LM Studio باید روشن و مدل Load شده باشد.

English | Setup
----------------------------------------
1) Extract the GameAgentLab_V2 folder.
2) Install Python 3.10+ and enable Add Python to PATH.
3) Start LM Studio 0.4.0+ (required for native `/api/v1/chat`) and load google/gemma-4-e4b with Vision support.
4) Open Local Server in LM Studio and listen on 127.0.0.1:1234.
5) Double-click start_gameagentlab_v2.bat.
6) On first launch, the script creates a virtual environment and installs requirements.
7) Open http://localhost:8001 in your browser.
8) Upload your game ZIP, select the project, generate/edit the prompt, and run the Agent.
9) Review the logs, download the ZIP, and manually test the game.
10) If a mission fails, click “🧠 Analyze Logs” in the Live Console. LM Studio diagnoses the failure and automatically feeds its findings into Prompt Generator to create a repair prompt.
11) To attach a visual reference, click VISION in the Prompt Generator header, select a PNG/JPG/WEBP image, write your request, then click Generate Prompt. The image and text are sent together to LM Studio. Maximum image size: 12 MB.

Safety notes:
- A full mission snapshot is stored outside the project in workspace/.backups.
- Incomplete agent runs are rolled back.
- New JavaScript syntax errors and newly missing local HTML assets trigger rollback.
- Pre-existing baseline issues are reported but do not alone trigger rollback.
- split_file is disabled because heuristic JavaScript splitting can break scope and load order.
- write_file is restricted to new files. Existing files must use edit_file.
- Agent shell command execution is disabled by default.
- Static checks cannot guarantee runtime correctness; manually test gameplay after every task.
- Node.js is recommended for JavaScript syntax checks.
- The server binds to localhost. Do not expose it to an untrusted network without authentication.
- The log analyzer is read-only: it diagnoses and creates a repair prompt but does not directly edit project files. LM Studio must be running with the configured model loaded.

Model: google/gemma-4-e4b
LM Studio API: http://127.0.0.1:1234/v1
GameAgentLab: http://localhost:8001
Version: 2.2.1
Author credit retained: VARAGOD
\n\nIMPORTANT / نکته مهم:\nGameAgentLab V2 uses http://localhost:8001. Version 1 may continue using http://localhost:8000. Keep the launcher window open while using V2.\nنسخه ۲ از آدرس http://localhost:8001 استفاده می‌کند. نسخه ۱ می‌تواند همچنان روی پورت ۸۰۰۰ فعال باشد. هنگام استفاده از نسخه ۲ پنجره اجرا را نبندید.\n
VISION NOTES / نکات قابلیت بینایی
----------------------------------------
- The VISION button attaches one reference image to Prompt Generator; it does not automatically copy the image into the game project.
- Supported formats: PNG, JPEG/JPG, WEBP. Maximum original file size: 12 MiB.
- The configured model google/gemma-4-e4b must be loaded with vision support in LM Studio. A different selected model must also be a vision-language model (VLM).
- Image input uses LM Studio native REST `POST /api/v1/chat` with `type: image` and `data_url`, then its textual analysis is sent to the existing tool-enabled prompt generator. This avoids the affected OpenAI-compatible `image_url` data-URI parser path. If the native endpoint is unavailable, update LM Studio and confirm a vision-capable model is loaded.
- قابلیت VISION تصویر و متن را با API بومی `/api/v1/chat` تحلیل می‌کند و خلاصه آن را به تولید پرامپت ابزارمحور می‌دهد؛ خودش تصویر را داخل پوشه پروژه ذخیره نمی‌کند.
- فرمت‌های PNG، JPG و WEBP پشتیبانی می‌شوند؛ حداکثر حجم فایل ۱۲ مگابایت است.
- مدل پیش‌فرض google/gemma-4-e4b در LM Studio ورودی تصویر دارد. اگر مدل دیگری انتخاب شد، باید از نوع Vision-Language باشد.
