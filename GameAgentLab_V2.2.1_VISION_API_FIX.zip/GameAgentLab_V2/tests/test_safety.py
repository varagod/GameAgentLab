import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
# Tests exercise local safety helpers; LM Studio SDK is not needed.
try:
    import openai  # noqa
except ImportError:
    import types
    fake = types.ModuleType('openai')
    class FakeOpenAI:
        def __init__(self, *args, **kwargs): pass
    fake.OpenAI = FakeOpenAI
    sys.modules['openai'] = fake
import agent

class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.project = Path(self.tmp.name) / 'project'
        self.project.mkdir()
        (self.project / 'index.html').write_text('<html><script src="app.js"></script></html>', encoding='utf-8')
        (self.project / 'app.js').write_text('const ok = true;\n', encoding='utf-8')

    def tearDown(self):
        self.tmp.cleanup()

    def test_path_traversal_blocked(self):
        with self.assertRaises(ValueError):
            agent._safe_path(str(self.project), '../outside.txt')

    def test_absolute_path_blocked(self):
        with self.assertRaises(ValueError):
            agent._safe_path(str(self.project), '/etc/passwd')

    def test_split_disabled(self):
        self.assertIn('حذف شده', agent.split_file(str(self.project), 'app.js', 10))

    def test_write_file_does_not_overwrite(self):
        result = agent.write_file(str(self.project), 'app.js', 'const broken = false;')
        self.assertIn('از قبل وجود دارد', result)
        self.assertEqual((self.project / 'app.js').read_text(encoding='utf-8'), 'const ok = true;\n')

    def test_write_file_creates_new(self):
        result = agent.write_file(str(self.project), 'new.js', 'const fresh = 1;')
        self.assertIn('ذخیره شد', result)
        self.assertTrue((self.project / 'new.js').exists())


    def test_mission_snapshot_and_restore(self):
        old_workspace = agent.WORKSPACE_DIR
        try:
            agent.WORKSPACE_DIR = str(Path(self.tmp.name) / 'workspace')
            Path(agent.WORKSPACE_DIR).mkdir()
            project = Path(agent.WORKSPACE_DIR) / 'game'
            project.mkdir()
            (project / 'index.html').write_text('original', encoding='utf-8')
            snapshot = agent._snapshot_project(str(project))
            (project / 'index.html').write_text('changed', encoding='utf-8')
            agent._restore_snapshot(str(project), snapshot)
            self.assertEqual((project / 'index.html').read_text(encoding='utf-8'), 'original')
        finally:
            agent.WORKSPACE_DIR = old_workspace

    def test_edit_file_creates_backup_outside_project(self):
        old_workspace = agent.WORKSPACE_DIR
        try:
            workspace = Path(self.tmp.name) / 'workspace'
            project = workspace / 'demo'
            project.mkdir(parents=True)
            (project / 'code.js').write_text('const x = 1;', encoding='utf-8')
            agent.WORKSPACE_DIR = str(workspace)
            result = agent.edit_file(str(project), 'code.js', 'const x = 1;', 'const x = 2;')
            self.assertIn('ویرایش انجام شد', result)
            self.assertTrue((workspace / '.file_backups' / 'demo' / 'code.js.' ).parent.exists())
            self.assertEqual((project / 'code.js').read_text(encoding='utf-8'), 'const x = 2;')
        finally:
            agent.WORKSPACE_DIR = old_workspace

    def test_log_analyzer_uses_lm_studio_and_returns_diagnosis(self):
        class FakeMessage:
            content = 'علت خطا: آکولاد بسته نشده است. راهکار: ساختار تابع را اصلاح کن.'
        class FakeChoice:
            message = FakeMessage()
        class FakeResponse:
            choices = [FakeChoice()]
        class FakeCompletions:
            def __init__(self): self.kwargs = None
            def create(self, **kwargs):
                self.kwargs = kwargs
                return FakeResponse()
        class FakeChat:
            def __init__(self): self.completions = FakeCompletions()
        class FakeClient:
            def __init__(self): self.chat = FakeChat()

        old_client = agent.client
        fake = FakeClient()
        try:
            agent.client = fake
            result = agent.analyze_mission_logs('Syntax error at line 80', 'test-game')
            self.assertIn('آکولاد', result)
            self.assertEqual(fake.chat.completions.kwargs['model'], agent.MODEL_NAME)
            self.assertIn('Syntax error at line 80', fake.chat.completions.kwargs['messages'][1]['content'])
        finally:
            agent.client = old_client

    def test_log_analyzer_rejects_empty_logs(self):
        with self.assertRaises(ValueError):
            agent.analyze_mission_logs('   ')


    def test_vision_png_data_url_validation(self):
        import base64
        png_bytes = b"\x89PNG\r\n\x1a\n" + b"test-image-payload"
        data_url = "data:image/png;base64," + base64.b64encode(png_bytes).decode("ascii")
        self.assertEqual(agent.validate_vision_image_data_url(data_url), data_url)

    def test_vision_rejects_mime_signature_mismatch(self):
        import base64
        jpeg_bytes = b"\xff\xd8\xff" + b"test-image-payload"
        data_url = "data:image/png;base64," + base64.b64encode(jpeg_bytes).decode("ascii")
        with self.assertRaises(ValueError):
            agent.validate_vision_image_data_url(data_url)

    def test_vision_rejects_unsupported_data_url(self):
        with self.assertRaises(ValueError):
            agent.validate_vision_image_data_url("data:image/gif;base64,R0lGODlh")

    def test_prompt_content_includes_visual_analysis_and_text(self):
        analysis = "بدنه استوانه‌ای تیره با مخزن آبی در قسمت پایین."
        content = agent.build_prompt_user_content("این تصویر را به بازی اضافه کن", "index.html", analysis)
        self.assertIsInstance(content, str)
        self.assertIn("این تصویر را به بازی اضافه کن", content)
        self.assertIn("تحلیل تصویری", content)
        self.assertIn(analysis, content)

    def test_native_vision_request_uses_data_url_contract(self):
        import base64
        from unittest.mock import Mock, patch
        png_bytes = b"\x89PNG\r\n\x1a\n" + b"test-image-payload"
        data_url = "data:image/png;base64," + base64.b64encode(png_bytes).decode("ascii")
        fake_response = Mock()
        fake_response.json.return_value = {"output": [{"type": "message", "content": "تحلیل تصویری تست"}]}
        fake_response.raise_for_status.return_value = None
        fake_http = Mock()
        fake_http.post.return_value = fake_response
        with patch.object(agent, "http_client", fake_http):
            result = agent.analyze_vision_image(data_url, "این تصویر چیست؟")
        self.assertEqual(result, "تحلیل تصویری تست")
        args, kwargs = fake_http.post.call_args
        self.assertEqual(args[0], agent.LM_STUDIO_NATIVE_CHAT_URL)
        payload = kwargs["json"]
        self.assertEqual(payload["input"][0]["type"], "image")
        self.assertEqual(payload["input"][0]["data_url"], data_url)
        self.assertEqual(payload["input"][1]["type"], "text")
        self.assertIn("این تصویر چیست؟", payload["input"][1]["content"])

    def test_generate_prompt_analyzes_image_then_uses_tool_chat_text_only(self):
        import base64
        from types import SimpleNamespace
        from unittest.mock import Mock, patch
        png_bytes = b"\x89PNG\r\n\x1a\n" + b"test-image-payload"
        data_url = "data:image/png;base64," + base64.b64encode(png_bytes).decode("ascii")
        fake_message = SimpleNamespace(tool_calls=None, content="پرامپت تستی\nپایان")
        fake_response = SimpleNamespace(choices=[SimpleNamespace(message=fake_message)])
        create = Mock(return_value=fake_response)
        fake_client = SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)))
        with patch.object(agent, "analyze_vision_image", return_value="شرح تصویر مرجع"), \
             patch.object(agent, "client", fake_client):
            result = agent.generate_prompt("این تصویر را بررسی کن", str(self.project), data_url)
        self.assertIn("پرامپت تستی", result)
        sent_messages = create.call_args.kwargs["messages"]
        user_content = sent_messages[1]["content"]
        self.assertIsInstance(user_content, str)
        self.assertIn("شرح تصویر مرجع", user_content)
        self.assertIn("این تصویر را بررسی کن", user_content)

    def test_prompt_content_without_image_remains_text(self):
        content = agent.build_prompt_user_content("درخواست متنی", "index.html")
        self.assertIsInstance(content, str)
        self.assertIn("درخواست متنی", content)

    def test_validator_detects_missing_asset(self):
        (self.project / 'index.html').write_text('<script src="missing.js"></script>', encoding='utf-8')
        issues = agent._collect_validation_issues(str(self.project))
        self.assertTrue(any('Missing asset' in x for x in issues))

    def test_validator_detects_js_syntax_when_node_exists(self):
        if not __import__('shutil').which('node'):
            self.skipTest('Node.js unavailable')
        (self.project / 'app.js').write_text('function ( {', encoding='utf-8')
        issues = agent._collect_validation_issues(str(self.project))
        self.assertTrue(any('JavaScript syntax' in x for x in issues))

if __name__ == '__main__':
    unittest.main(verbosity=2)
